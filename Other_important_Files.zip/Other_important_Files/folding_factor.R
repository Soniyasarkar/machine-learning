data <- read.csv("C:\\Users\\v.behl\\Documents\\test_ff.csv")

x<-unique(data[,c('Browser_id','Category')])
x[1,]$Browser_id
expected_rev <- list()
expected_rev[[1]] <- 0
rep(c(1), times = )

x<- list()
x[[1]] <-1
x[[2]] <-2
x[[3]] <-3
x[[4]] <-4
x[c(1:length(x))]
row.names(x) <- NULL
pred_revenue_ff <- function(data,ff)
{
  x<-unique(data[,c('Browser_id','Category')])
  cat(nrow(x))
  row.names(x) <- NULL ## reset index
  output_data <- data.frame()
  top <- 2*ff
  
  for (index in 1:nrow(x))
  {
    data$One <-1
    b_id <-  x[index,]$Browser_id
    keyword <-  x[index,]$Category
    temp <- subset(data, (Browser_id == b_id) & (Category == keyword) )
    expected_rev <- list() ## creating predicted revenue list
    factor <-  2**(-1/ff)
    expected_rev[[1]] <- 0
    denominator <- list()
    denominator[[1]]<-0
    denominator[[2]]<-1
    #first_val <- temp$Expected[1]
    #cat(first_val
    #cat(nrow(temp))
    numerator <- list()
    numerator[[1]]<-0
    numerator[[2]]<-temp$Expected[1]
    expected_rev[[2]] <- numerator[[2]]/denominator[[2]]
    for (itr in 3:nrow(temp))
    {
      if (itr <= (2*ff + 1)) 
      {
      numerator[[itr]]<- numerator[[itr-1]]*factor + temp$Expected[[itr-1]]
      denominator[[itr]]<- denominator[[itr-1]]*factor + 1
      expected_rev[[itr]]<-numerator[[itr]]/denominator[[itr]]
      
      }
      else
      {
        numerator_window_list <- list()
        denominator_window_list <- list()
        est_rev <- list()
        numerator_window_list <- numerator[c((itr -2*ff):length(numerator))]
        denominator_window_list <- rep(c(1),times=2*ff)
        est_rev <- temp$Expected[c((itr -2*ff):length(numerator))]
      

        cat(itr)
        #for (itr2 in  ((itr -2*ff) + 1): itr)
        for (itr2 in 2 : length(est_rev)) ## Change 
          
        {
          print(itr2)
          #numerator_window_list[[itr2]]<- est_rev[[itr2-1]]*factor + temp$Expected[[itr2-1]]
          est_rev[[itr2]]<- est_rev[[itr2-1]]*factor + est_rev[[itr2]]
          cat(est_rev[[itr2]])
          cat("\n")
          
          denominator_window_list[[itr2]]<- denominator_window_list[[itr2-1]]*factor + 1
          # 
        }
        cat("\n")
        numerator[[itr]]<- est_rev[[itr2]] ## change 
        denominator[[itr]]<- denominator_window_list[[itr2]]  ## change
        expected_rev[[itr]]<-numerator[[itr]]/denominator[[itr]] ## change
      }
    }
    temp$den <-denominator
    temp$num <-numerator
    
    temp$last_col <-expected_rev
    
    output_data <- rbind(output_data,temp)
  }
  colnames(output_data)[ncol(output_data)] <- paste("expected_ff_",ff,sep = '')
  
  return(output_data)
}


out_df<-pred_revenue_ff(data,4)
predicted_rev < c()

predcited_rev[itr] 
num <- counter*factor*first_val + temp$expected_price[itr-1]
predcited_rev[itr]  


x[1,]$Browser_id

temp <- subset(data, (Browser_id == 261) & (Category == 'A') )
