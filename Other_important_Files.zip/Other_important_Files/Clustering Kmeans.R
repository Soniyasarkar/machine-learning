library(stats)
library(factoextra)
library(cluster)
#load("C:\\Users\\AKASH.POL\\Documents\\Projects\\Del Monte\\Work\\Clustering\\Clustering\\dataforsegmentation.rdata")

data1 <- read.csv("C:\\Users\\AKASH.POL\\Documents\\PROJECTS\\WIP\\Houston_zip_level_derived_variablesold.csv")

#originaldata<-dataforsegmentation
# dataforsegmentation$MeanVolume<-NULL
# dataforsegmentation$SDVolume<-NULL
# dataforsegmentation$Amount<-(dataforsegmentation$TotalVolume*dataforsegmentation$Priceperunitoverall)/10000
# dataforsegmentation$TotalVolume<-dataforsegmentation$TotalVolume/1000
# dataforsegmentation$Priceperunitoverall<-NULL
# dataforsegmentation$TotalOrders<-dataforsegmentation$TotalOrders/10
# dataforsegmentation$Shelflifeoverall<-dataforsegmentation$Shelflifeoverall/10
# dataforsegmentation$COVVolume<-dataforsegmentation$Shelflifeoverall*10

colnames(data1)[1] <- "athena_zip_5"

#data1<-na.omit(data) 
datakey<-as.data.frame(data1$athena_zip_5)
data<-data1[,-1]
#as.numeric(data)
head(data)
head(datakey)

pca<-prcomp(data, center = TRUE,scale. = TRUE)

library(ggplot2)
library(ggfortify)

d <- autoplot(pca, data=data, loadings=TRUE,colour = 'orange', loadings.colour = "black",label = TRUE, scale = 1,loadings.label = TRUE,)+
  scale_colour_manual(values=c("forestgreen","red","blue")) +
  scale_fill_manual(values=c("forestgreen","red","blue")) +
  scale_shape_manual(values=c(25,22,23))+
  theme_bw()

d$layers[[2]]$aes_params$size <- 0.5
d$layers[[2]]$geom_params$arrow$length <- unit(6, units = "points")
d


fviz_nbclust(x = data,FUNcluster = kmeans, method = 'wss' )

#gap_stat <- clusGap(x = data, FUN = kmeans, K.max = 15, nstart = 25, B = 50 )

#fviz_gap_stat(gap_stat)




clusters_products <- kmeans(data, centers = 5, nstart = 25)
print(clusters_products)

fviz_cluster(clusters_products, data = data)


library(gridExtra)
library(grid)
library(ggplot2)
library(lattice)

products_K3 <- kmeans(data, centers = 3, nstart = 25)
products_K4 <- kmeans(data, centers = 4, nstart = 25)
products_K5 <- kmeans(data, centers = 5, nstart = 25)
products_K6 <- kmeans(data, centers = 6, nstart = 25)

p1 <- fviz_cluster(products_K3, geom = "point", data = data) + ggtitle(" K = 3")
p2 <- fviz_cluster(products_K4, geom = "point", data = data) + ggtitle(" K = 4")
p3 <- fviz_cluster(products_K5, geom = "point", data = data) + ggtitle(" K = 5")
p4 <- fviz_cluster(products_K6, geom = "point", data = data) + ggtitle(" K = 6")

grid.arrange(p1, p2, p3, p4, nrow = 2)

library(dplyr)
data<-data %>% 
  mutate(Cluster = products_K4$cluster)


data<-cbind(datakey,data)
colnames(data)
#data$Material<-data$`data$Material`
#data$`data$Material`<-NULL

materialcluster<-data%>% 
  dplyr::select(data1$athena_zip_5,Cluster)



originaldata<-merge(originaldata,materialcluster,by=c("Material"),all.x = TRUE)

originaldata$Cluster[is.na(originaldata$Cluster)] <- 4





library(plotly)
plot_ly(originaldata
        , x = originaldata$TotalVolume
        , y = originaldata$Shelflifeoverall
        , z = originaldata$COVVolume
        , color = ~Cluster,
        colors = c('#BF382A', '#0C4B8E','#9999CC','#66CC99')) %>%
  add_markers() %>%
  layout(scene = list(
    xaxis = list(title = "TotalVolume"),
    yaxis = list(title = "Shelflifeoverall")
    ,zaxis = list(title = "COVVolume")
  ),
  title = "Cluster Analysis")


library(plotly)
plot_ly(originaldata
        , x = originaldata$TotalOrders
        , y = originaldata$COVVolume
        
        , color = ~Cluster,
        colors = c('#BF382A', '#0C4B8E','#9999CC','#66CC99')) %>%
  add_markers() %>%
  layout(scene = list(
    xaxis = list(title = "TOtalOrders"),
    yaxis = list(title = "COVVolume")
    
  ),
  title = "Cluster Analysis")


