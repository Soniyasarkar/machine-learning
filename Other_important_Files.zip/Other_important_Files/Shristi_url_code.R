
install.packages("dplyr")
library("dplyr")
list_url<- c('https://m.activebeat.com/diet-nutrition/5-things-you-should-know-about-quinoa',
  'https://m.activebeat.com/diet-nutrition/5?p',
  'https://m.activebeat.com/diet-nutrition/5/7/',
  'https://m.activebeat.com/diet-nutrition/5/')

str <- 'https://m.activebeat.com/your-health/sleep-tight-dont-let-the-bed-bugs-bite?page=2/jbdauegv'
clean_url <- function(url_text)
{
text <-url_text
n_last <- 1
last_var <- last(unlist(strsplit(text, "/")))
last_el <- substring(text, nchar(text) - n_last + 1, nchar(text))
if (last_el %in% c("/","@","&","#","*"))
   {

   text <- substring(text, 1, nchar(text)-n_last)
   }
if (regexpr('[+?#*]',last_var)[1] != -1) 
   {
   sc_pos <- regexpr('[+?#*]',last_var)[1]
      last_var_pos <- regexpr(unlist(strsplit(last_var,"-"))[1],text)[1]
   return(substring(text,1,last_var_pos +sc_pos -2))
}
}
clean_url(str)

last_var <- last(unlist(strsplit(str, "/")))
unlist(strsplit(last_var,"-"))[1]

unlist(regexpr("sleep",str))

regexpr('[+?#*]',last_var)[1]
sc_pos <- regexpr('[+?#*]',last_var)[1]
last_var_pos <- regexpr(last_var,text)[1]
substring(text,1,last_var_pos +sc_pos -2)

# a<- unlist(strsplit(text, "/"))
# a<- a[a!= last_var]
# print(a)
# updated_url = paste(a,collapse= "/")
# updated_url

gsub("[+@*?&/\\-]", "", "/")


page_num_func <- function(str)
{
   #### SLASHES REPLACED WITH ?page
  last_var <- last(unlist(strsplit(str, "?page=")))
  a<- unlist(strsplit(str, "?page="))
  updated_url = paste(a,collapse= "?page=")
 if (!is.na(as.numeric(last_var) == TRUE)){
   a<- unlist(strsplit(str, "?page="))
   a_<- a[a!= last_var]
   updated_url = paste(a_,collapse= "/")
   
   return(c(last_var,updated_url))
   
 }
  ####### THIS PART IS ADDED ###
 else if (grepl(str,"?page=", fixed = TRUE) == FALSE){
   return(c("1",updated_url))
 }
  ##### PLEASE COMMENT THIS PART
 #else if (substring(last(unlist(strsplit(str, "/"))),1,1) == "?") {
  # last_var <- last(unlist(strsplit(updated_url, "/")))
   #a<- unlist(strsplit(str, "/"))
   #a_<- a[a!= last_var]
   #updated_url = paste(a_,collapse= "/")
   #return(c("NA",updated_url))}
 else { return(c("1",updated_url))}
}

clean_url(str)

b<-lapply(list_url,page_num_func)

url_Column <- unlist(lapply(b, '[[', 2))
page_num_Column <- unlist(lapply(b, '[[', 1))


