
# coding: utf-8

# In[5]:

from bs4 import BeautifulSoup


# In[6]:

import requests
import json
import urllib2
import pandas as pd


# In[10]:

df = pd.DataFrame(columns=['Title','Link'])
cancerwebsite="https://www.cancercompass.com"
for i in xrange(0,19):
    link = ("https://www.cancercompass.com/message-board/cancers/melanoma/1,"+str(i)+",119,11.htm")
    cancerCompass = requests.get(link)
    soup = BeautifulSoup(cancerCompass.content, 'html.parser')
    tableContent = soup.find(class_="mbDis")
    for disc in tableContent.find_all(class_="subLink"):
        df= df.append({'Link': cancerwebsite+disc['href'],'Title': disc.text.strip()}, ignore_index=True)
        print df


# In[9]:

df1 = pd.DataFrame(columns = ['Title','User','Date','Post'])
i=0
for item in df.Link:
    post1 = requests.get(item)
    soup = BeautifulSoup(post1.content, 'html.parser')
    for item in soup.find_all(class_="message"):
            good1=item.find(class_="header")
            title=good1.find("h3")
            user_info=good1.find("p")
            user= user_info.text.strip()
            user_with_date = str(user_info.text.strip()).split('on ', 1)[-1]
            good2=item.find(class_="msgContent")
            title_temp=title.text.strip().encode('utf-8')
            user_temp=user.split()[1].encode('utf-8')
            date_temp=user_with_date.encode('utf-8')
            post_temp=good2.text.strip().encode('utf-8')
            print title_temp,i
            i=i+1
            df1 = df1.append({'Title': title_temp , 'User' : user_temp,'Date' : date_temp, 'Post' : post_temp}, ignore_index=True)
df1.to_csv("C:\\Users\\Arpita.Sharma\\Documents\\testdir\\f1.csv", sep=',', encoding='utf-8')

