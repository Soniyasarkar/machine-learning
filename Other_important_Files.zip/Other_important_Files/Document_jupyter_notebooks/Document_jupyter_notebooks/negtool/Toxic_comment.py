# Importing necassary packages 
import string
import pandas as pd
import numpy as np
import nltk
import re

# Sklearn package to import necessary vectorizing algorithms
from sklearn.feature_extraction.text import TfidfTransformer,TfidfVectorizer

#NLTK package for text mining operations 
from nltk.corpus import stopwords as sw
from nltk.corpus import wordnet as wn
from nltk import wordpunct_tokenize
from nltk import WordNetLemmatizer
from nltk import sent_tokenize
from nltk.tokenize import sent_tokenize
from nltk import pos_tag

from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report as clsr
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
from sklearn.naive_bayes import MultinomialNB
from sklearn.neighbors import KNeighborsClassifier
import pickle
from sklearn.cross_validation import KFold
from nltk.tokenize import sent_tokenize
from scipy import sparse , vstack , hstack
from sklearn.svm import SVC
from sklearn.utils import check_random_state, safe_indexing

# Reading the sentenced tokenized dataset
posts = pd.read_csv('toxic_data.csv')

## Pre-processing the text column

#lemmatizer = WordNetLemmatizer()

def identity(arg):
    """
    Simple identity function works as a passthrough.
    """
    return arg

## Removing HTML tags
def cleanhtml(raw_html):
    cleanr = re.compile(r'<[^>]+>')
    cleantext = re.sub(cleanr, '', raw_html)
    return cleantext

## Removing URL
def strip_URL(text):
    return re.sub(r'(https|http)?:\/\/(\w|\.|-|\/|\?|\=|\&|\%)*\b', '', text, flags=re.MULTILINE)

## Removing Hashtags and '@' tags 
def strip_all_tags(text):
    entity_prefixes = ['@','#','[]']
    for separator in  string.punctuation:
        if separator not in entity_prefixes :
            text = text.replace(separator,' ')
    words = []
    for word in text.split():
        word = word.strip()
        if word:
            if word[0] not in entity_prefixes:
                words.append(word)
    return ' '.join(words)

## Removing special characters 
def strip_special_chars(text):
    return re.sub('\W+',' ', text)

## Removing extra white spaces
def strip_extra_white_spaces(text):
    return re.sub(' +',' ',text).strip()

## Removing extra new lines
def strip_extra_new_lines(text):
    return re.sub("\n+","\n", text)

def inverse_transform(l):
        sent = ''
        for word in l:
            sent += word+" "
        return [sent]


def tokenize(document):
    document = cleanhtml(document)
    document = strip_URL(document)
    document = strip_all_tags(document)
    document = strip_special_chars(document)
    document = strip_extra_white_spaces(document)
    document = strip_extra_new_lines(document)
    stopwords_custom = pd.read_csv("stopwords1.csv")
    stopwords_custom = stopwords_custom.iloc[:,0].map(lambda x:x.lower())
        
    #Breaking the document into sentences
    for sent in sent_tokenize(document):
        # Breaking the sentence into parts of speech-tagged tokens
        for token, tag in pos_tag(wordpunct_tokenize(sent)):
            # Applying pre-processing to the token
            token = token.lower() 

            #If there is a stopword, ignore the token and continue
            if token.lower in stopwords_custom.tolist():
                continue

            # If there is a punctuation, ignore the token and continue
            if all(char in string.punctuation for char in token):
                  continue
            
            yield token

#Lemmatize the token and yield
            #lemma = lemmatize(token, tag)
            #yield lemma

def lemmatize(token, tag):
    tag = {
       'N': wn.NOUN,
       'V': wn.VERB,
       'R': wn.ADV,
       'J': wn.ADJ
    }.get(tag[0], wn.NOUN)

    #return lemmatizer.lemmatize(token, tag)
    
def preprocessing(X):
    #tokens_dict = {}
    tokens_list = []
    count = 0
    for doc in X:
        tokens = list(tokenize(doc))
        # tokens_list
        tokens_list.append(tokens)
#tokens_dict[count] = inverse_transform(tokens) count += 1
    return tokens_list

    
    
words= preprocessing(posts['comment_text'])

List_strings =[] 
for i in words:
    a = " ".join(str(x) for x in i)
    List_strings.append(a) 
    

posts['Comment'] = List_strings

posts.to_csv('Toxic_comment_filter_data.csv' , index = False)