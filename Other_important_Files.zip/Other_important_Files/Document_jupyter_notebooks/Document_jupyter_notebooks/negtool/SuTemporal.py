import os
import json
from sutime import SUTime

jar_files = 'C:/Users/varun.behl/Documents/python-sutime-master/sutime/jars/'
sutime = SUTime(jars=jar_files,jvm_started= True, mark_time_ranges=False , include_range= False )


text = 'Phil got his 5th of july cells back at MD Anderson on May 9th, and is scheduled to start his second week of high dose Aldesleukin on Wednesday.'
date ='4/16/2012  12:00:00 AM'
print sutime.parse(text , reference_date= date)