import numpy as np
import pandas as pd
import re
import nltk
import collections
import os
import tempDrugOrderNegTag as tag
from sutime import SUTime

global pattern_dict
global word_dict

jar_files = 'C:/Users/varun.behl/Documents/python-sutime-master/sutime/jars/'
sutime = SUTime(jars=jar_files,jvm_started= False , mark_time_ranges= True , include_range= True )
sutime = SUTime(jars=jar_files,jvm_started= True , mark_time_ranges= True , include_range= True )


# text = "I am taking Ipilimumab for last 10 months. Before that I was on Nivolumab from January 2015. But instead of Ipilimumab I should have taken Vemurafenib for 10 days"
# postDate = "3/7/2018  12:00:00 AM"

def get_index(typeString,replaceString,words_list,text):
    global pattern_dict
    global word_dict
    words = []
    #print type(words_list)
    for i in range(0,len(words_list)):
        #print words_list[i]
        words.append(words_list[i]) 
        text = re.sub(words_list[i],replaceString ,text)
        
    z = text
    a = nltk.word_tokenize(z)
    replaceString = replaceString.split(' ')[1]
    ind = [index for index, value in enumerate(a) if value == replaceString]
    count = 0
    for i in ind:
        pattern_dict[i] = typeString
        word_dict[i] = words[count]
        count +=1
        
    return text

def patternExtract(text, postDate):
    global pattern_dict
    global word_dict
    pattern_dict = {}
    word_dict = {}
    
    x = sutime.parse(text , reference_date= postDate)
    
    
    Temporal = []
    Temp_pattern = []
    Temp_conversion  = []
    Temp_index  = []
    
    
    for i in range(len(x)):
        Temporal.append(x[i]['text'].encode('utf-8'))
        #print Temporal
        Temp_pattern.append('T'+re.escape(str(i)))
        try:
            Temp_conversion.append(x[i]['value'].encode('utf-8'))
        except:
            Temp_conversion.append('DURATION')
    
    
    drug_words = tag.drug_tag(text)
    order_words = tag.order_words(text)
    neg_words = tag.neg_tag(text)
   


    drug_count = 0
    neg_count = 0
    order_count = 0

    text_1 = get_index('D',' DRUG ',drug_words,text)
    text_2 = get_index('O',' ORDER ',order_words,text)
    text_3 = get_index('N',' NEG ',neg_words,text)
    for i in Temporal:
        z = re.sub(i,"TEMPORAL" ,text)
        #print z
        try:
            a = nltk.word_tokenize(z)
            Temp_index.append(a.index('TEMPORAL')) 
        except: 
            z = z.replace('TEMPORAL' , ' TEMPORAL ')
            a = nltk.word_tokenize(z)			
            Temp_index.append(a.index('TEMPORAL'))     
    
    
    
    od_pattern = collections.OrderedDict(sorted(pattern_dict.items()))
    od_words = collections.OrderedDict(sorted(word_dict.items()))

    indices = list(od_pattern.keys())
    pattern = list(od_pattern.values())
    words = list(od_words.values())

    return pattern, indices, words , Temporal , Temp_pattern , Temp_conversion , Temp_index

# pattern, ind, words = patternExtract(text, postDate)
# print pattern
# print ind
# print words