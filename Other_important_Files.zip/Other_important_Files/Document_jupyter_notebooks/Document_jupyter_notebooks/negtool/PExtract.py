import numpy as np
import pandas as pd
import re
import TOPN as tag
from temp2date import temp_to_data
import collections

global pattern_dict
global word_dict

#text = ' for 4th of july "\nIpilumumab" you\'ll see a lot of difference for 10 days on 2/12' 
#postDate = "3/7/2018  12:00:00 AM"

def get_index(typeString,replaceString,words_list,text):
    global pattern_dict
    global word_dict
    words_unique = np.unique(words_list).tolist()
    words_sorted = sorted(words_unique, key=len, reverse=True)
    for word in words_sorted:
        text = re.sub(word.strip(" "),word.replace(" ","")+(" "),text)
        text_list = text.split(" ")
        ind = np.where(np.asarray(text_list)==word.replace(" ",""))[0]
        for i in ind:
            pattern_dict[i] = typeString
            word_dict[i] = word
        text = re.sub(word.replace(" ",""),replaceString,text)
    return text

def patternExtract(text, postDate):
    global pattern_dict
    global word_dict
    pattern_dict = {}
    word_dict = {}
    
    temp_words = tag.temporal_tag(text)
    for r in (('(',' \( '),(')',' \) '),('[','\['),(']','\]'),('-',' - '),('=',' '),('~',' '),('{',' '),(',',' , '),('+',' '),(':',' : '),('"',' '),('.',' . '),('\n',' '),('\t',' '),('\r',' ')):
        text = text.replace(*r)
    text = re.sub(' +',' ',text).strip()
    
    temp_converted = []
    for temp in temp_words:
        try:
            temp_converted.append(temp_to_data(temp,postDate))
        except:
            print temp
            print text
            print postDate
    drug_words = tag.drug_tag(text)
    order_words = tag.order_words(text)
    neg_words = tag.neg_tag(text)
    #print "Order words:",order_words
    #print "Neg words:",neg_words

    temp_ind = np.where(np.asarray(temp_converted)!=None)[0]
    temporal = [temp_words[i] for i in temp_ind]
    #print "Temporal words:", temporal

    period_ind = np.where(np.asarray(temp_converted)==None)[0]
    period = [temp_words[i] for i in period_ind]
    #print "Period words:", period

    drug_count = 0
    temp_count = 0
    period_count = 0
    order_count = 0

    text = get_index('D','DRUG',drug_words,text)
    text = get_index('T','TEMP',temporal,text)
    text = get_index('P','PERIOD',period,text)
    text = get_index('O','ORDER',order_words,text)
    text = get_index('N','NEG',neg_words,text)

    od_pattern = collections.OrderedDict(sorted(pattern_dict.items()))
    od_words = collections.OrderedDict(sorted(word_dict.items()))

    indices = list(od_pattern.keys())
    pattern = list(od_pattern.values())
    words = list(od_words.values())

    return pattern ,indices , words
    #, indices, words

#pattern, indices, words = patternExtract(text, postDate)
#print pattern
#print indices
#print words