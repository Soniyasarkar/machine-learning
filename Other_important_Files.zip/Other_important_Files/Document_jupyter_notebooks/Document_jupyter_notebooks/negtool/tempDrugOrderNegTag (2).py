import re
import numpy as np
import pandas as pd

# Predefined strings.

numbers = "(^a(?=\s)|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred|thousand)"
day = "(monday|tuesday|wednesday|thursday|friday|saturday|sunday|mon|tue|wed|thurs|thu|fri|sat|sun)" 
month = "(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)"
dmy = "(year|day|week|month)"
rel_day = "(today|yesterday|tomorrow|tonight|tonite|fortnight)"
exp1 = "(before|after|earlier|later|ago|back)"
exp2 = "(this|next|last|of|till|to|coming)"
exp3 = "(from|since|between|with|past)"

exp5 = "(start)"
iso = "\d+[/-]\d+"
year = "((?<=\s)\d{4}|^\d{4})"
 

orderwords = "(later|before|earlier|previous|then|subsequently|followed|post|prior|after)"

with open("updated_drugs.txt","r") as f:
    drug = f.read()
with open("combo_neg.txt","r") as f:
    combo_neg = f.read()
# drug = "(Pembrolizumab|Nivolumab|Ipilimumab|Interferon|Vemurafenib|Dasatinib|Cisplatin|Vinblastine Sulphate|Temador)"

regxp1 = "((\d+|(" + numbers + "[-\s]?)+) " + dmy + "s? " + "(" + exp1 + "|" + exp3 +"))"  ######  1900< numbers < 2020
regxp2 = "("+ "("+exp2+"|"+exp3+") "+"((\d+|(" + numbers + "[-\s]?)+) " + dmy + "s?))"
regxp3 = "("r"\b(?!\w)"+drug+r"\b(?!\w))"
regxp4 = "((\d+|(" + numbers + "[-\s]?)+) " + dmy + "s?"+")"
# regxp4 = "5 weeks "
regxp5 =  "("+ "(" + exp2+"|"+ exp3 + ")" + "(" + "( "+dmy+"s?)" + "| " +r"\b(?=\w)" + month+ r"\b(?=\w)"+"| " + day + "| " + rel_day + "| " + year + "| " + iso +")" + " "+ year +")"
regxp6 = "("+ "(" + exp2+"|"+ exp3 + ")" + "(" + "( "+dmy+"s?)" + "|" +r"\b(?=\w)" + month+ r"\b(?=\w)"+"|" + day + "| " + rel_day + "|" + year + "|" + iso +"))"
regxp7 = "("+ "(" "( "+dmy+"s?)" + "|" +  r"\b(?=\w)" + month+  r"\b(?=\w)" + "|" + day + "|" + rel_day + "|" + year+ "|" + iso +")" +" "+ exp2 +" "+ year+")"
regxp8 = "("+ "(" "( "+dmy+"s?)" + "|" + r"\b(?=\w)"+ month+ r"\b(?=\w)" +"|" + day + "|" + rel_day + "|" + year + "|" + iso +")" +" "+ year+")"
#regxp9 = "("+ "(" "( "+dmy+"s?)" + "| " + month+ "| " + day + "| " + rel_day + "| " + year + "| " + iso +")" +" ((\d+|(" + numbers + "[-\s]?)+)) "+")" 
regxp10 = "("r"\b(?=\w)"+month+r"\b(?!\w)"+" "+"(\d+|\b("+numbers+"\b[-\s]?)+))"


# regxp5 = "("+exp5 + "(" + "ed?" +"|"+"ing?" + ")" + "|" + exp3 + ")"
reg1 = re.compile(regxp1, re.IGNORECASE)
reg2 = re.compile(regxp2, re.IGNORECASE)
reg3 = re.compile(rel_day, re.IGNORECASE)
reg4 = re.compile(iso)
reg5 = re.compile(year)
reg6 = re.compile(regxp3,re.IGNORECASE)
reg7 = re.compile(regxp4,re.IGNORECASE)
reg8 = re.compile(regxp5,re.IGNORECASE)
reg9 = re.compile(regxp6,re.IGNORECASE)
reg10 = re.compile(regxp7,re.IGNORECASE)
reg11 = re.compile(regxp8,re.IGNORECASE)
reg12 = re.compile(month,re.IGNORECASE)
#reg13 = re.compile(regxp11,re.IGNORECASE)
regxp14 = re.compile(orderwords, re.IGNORECASE)
reg15 = re.compile(regxp10,re.IGNORECASE)

NEGATION = "(never|\bno\b|\bover\b|denied|not|wasn't|wasnt|havent|haven't|hasnt|hasn't|hadnt|hadn't|cant|can't|couldnt|couldn't|shouldnt|shouldn't|wont|won't|wouldnt|would not|wouldn't|dont|don't|doesnt|dosen't|didnt|didn't|isnt|isn't|arent|aren't|aint|n't|instead|but|rather)"

NEGATION_RE = re.compile(NEGATION, re.VERBOSE)
allowable_difference_temp = [1,2,3,5]
allowable_words_temp = [' and ']

allowable_difference_drug = [1,3,4,5,6,7,12]
allowable_words_drug = "(and|&|with|/|-|,|)"

drugexp = re.compile(allowable_words_drug,re.IGNORECASE)
neg_toBeRemoved = []

# def get_minDist(word_1, word_2, text):
#     string_between1 = re.search(word_1+'.*?'+word_2,text)
#     d1 = 999
#     d2 = 999
#     if string_between1:
#         d1 = len((string_between1.group()).split())-2
#     string_between2 = re.search(word_2+'.*?'+word_1,text)
#     if string_between2:
#         d2 = len((string_between2.group()).split())-2
#     return min(d1,d2)


def if_drugNegated(drug_group, orig_text):
    text = orig_text
    drug_group = np.unique(drug_group)
    for drug in drug_group:
        matches = re.findall("("+drug+")", text)
        #matches = reg6.findall(text)
        for mat in matches:
            neg_matches = map(lambda x:NEGATION_RE.search(x),list(mat))
            if all(elem is None for elem in neg_matches):
                continue
            else:
                drug_group = filter(lambda a: a != drug, drug_group)
                # print "DRUG NEGATION FOUND", drug
                # print orig_text
                break
    return drug_group

def if_negCloseToDrug(neg_group, orig_text):
    text = orig_text
    neg_group = np.unique(neg_group)
    for neg in neg_group:
        matches = re.findall("(\S+\s+|^)(\S+\s+|)"+neg+"(\s+\S+|)(\s+\S+|$)", text)
        drugCloseBy = 0
        for mat in matches:
            drug_matches = map(lambda x:reg6.search(x),list(mat))
            if all(elem is None for elem in drug_matches):
                continue
            else:
                drugCloseBy = 1
                break
        if drugCloseBy == 0:
            neg_group = filter(lambda a: a != neg, neg_group)
    return neg_group

def temporal_recur(timex_found, orig_text):
    dict_timex = {}
    dict_timex['start'] = []
    dict_timex['end'] = []
    for timex in timex_found:
        dict_timex['start'].append(orig_text.find(timex))
        dict_timex['end'].append(orig_text.find(timex)+len(timex))
    start = dict_timex['start']
    end_list = dict_timex['end']
    count = 0
    for end in end_list:
        end_ind = count
        count += 1
        for n in allowable_difference_temp:
            nextStart_ind = np.where(np.asarray(start)==end+n)
            if len(nextStart_ind[0])>0:
                start_ind = nextStart_ind[0][0]
                string_between = orig_text[end:end+n]
                if (string_between in allowable_words_temp) or (n in [1,2,3]):
                    new_timex = timex_found[end_ind]+string_between+timex_found[start_ind]
                    timex_found = list(np.delete(timex_found,[end_ind,start_ind]))
                    timex_found.append(new_timex)
                    timex_found = temporal_recur(timex_found,orig_text)
                    return timex_found
    return timex_found

def drug_recur(drug_found, orig_text):
    dict_drug = {}
    dict_drug['start'] = []
    dict_drug['end'] = []
    for drug in drug_found:
        dict_drug['start'].append(orig_text.find(drug))
        dict_drug['end'].append(orig_text.find(drug)+len(drug))
    start = dict_drug['start']
    end_list = dict_drug['end']
    count = 0
    for end in end_list:
        end_ind = count
        count += 1
        for n in allowable_difference_drug:
            nextStart_ind = np.where(np.asarray(start)==end+n)
            if len(nextStart_ind[0])>0:
                start_ind = nextStart_ind[0][0]
                string_between = orig_text[end:end+n]
                matches_forDrug = drugexp.findall(string_between)
                matches_forDrug = filter(lambda a: a != '', matches_forDrug)
                if ((len(matches_forDrug)>0) or (n==1)):
                    new_drug = drug_found[end_ind]+string_between+drug_found[start_ind]
                    drug_found = list(np.delete(drug_found,[end_ind,start_ind]))
                    drug_found.append(new_drug)
                    if n==1:
                        print "n==1",drug_found
                    # print drug_found
                    drug_found = drug_recur(drug_found,orig_text)
                    return drug_found
    return drug_found

def temporal_tag(text):
    # try:
    # Initialization
    timex_found = []
    orig_text = text

    ##WITH PRIORITY

    # Variations of this thursday, next year, etc
    found = reg2.findall(text)
    found = [a[0] for a in found if len(a) > 1]
    for timex in found:
        timex_found.append(timex)
        text = re.sub(timex,'',text)

    found = reg1.findall(text)
    found = [a[0] for a in found if len(a) > 1]
    for timex in found:
        timex_found.append(timex)
        text = re.sub(timex,'',text)

    found = reg7.findall(text)
    found = [a[0] for a in found if len(a) > 1]
    for timex in found:
        timex_found.append(timex)
        text = re.sub(timex,'',text)

    found = reg10.findall(text) 
    found = [a[0] for a in found if len(a) > 1] 
    
    for timex in found:
        timex_found.append(timex)
        text = re.sub(timex,'',text)

    found = reg15.findall(text)
    found = [a[0] for a in found if len(a) > 1]
    for timex in found:
        timex_found.append(timex)
        text = re.sub(timex,'',text)


    found = reg11.findall(text) 
    found = [a[0] for a in found if len(a) > 1] 
    for timex in found:
        timex_found.append(timex)
        text = re.sub(timex,'',text)

    found = reg8.findall(text)
    found = [a[0] for a in found if len(a) > 1]
    for timex in found:
        timex_found.append(timex)
        text = re.sub(timex,'',text)

    found = reg9.findall(text)
    found = [a[0] for a in found if len(a) > 1]
    for timex in found:
        timex_found.append(timex)
        text = re.sub(timex,'',text)
            
    found = reg5.findall(text)
    for timex in found:
        timex_found.append(timex)
        text = re.sub(timex,'',text)

    found = re.findall(((r'\d{2}/\d{2}/\d{4}')+ '|' + (r'\d{1}/\d{2}/\d{4}')+'|' +(r'\d{1}/\d{2}')+'|' +(r'\d{1}/\d{2}') ),text)
    #found = [a[0] for a in found if len(a) > 1]
    #print found
    for timex in found:
        timex_found.append(timex)
        text = re.sub(timex,'',text)

    # today, tomorrow, etc
    found = reg3.findall(text)
    for timex in found:
        timex_found.append(timex)
        text = re.sub(timex,'',text)
        
    found = reg12.findall(text)
    
    for timex in found:
        timex_found.append(timex)
        text = re.sub(timex,'',text)


    # ISO
    found = reg4.findall(text)  
    for timex in found:
        timex_found.append(timex)
        text = re.sub(timex,'',text)


    timex_found = temporal_recur(timex_found, orig_text)
    return timex_found 
    # for timex in timex_found:
    #     try:
    #         orig_text = re.sub(timex + '(?!</TIMEX2>)', '<TIMEX2>' + timex + '</TIMEX2>', orig_text)
    #     except:
    #         print 'In exception', timex
    #         timex = timex.split("(")[0]
    #         orig_text = re.sub(timex + '(?!</TIMEX2>)', '<TIMEX2>' + timex + '</TIMEX2>', orig_text)

    # return orig_text

    # except:
        # print text
def combo_neg_handle(drug_found,text):
    combo_negs_list = ['rather','but','over','instead']
    for combo_neg in combo_negs_list:
        combo_neg_matches = re.findall("(\S+\s+|^)(\S+\s+|)"+combo_neg+"(\s+\S+|)(\s+\S+|$)", text)
        if len(combo_neg_matches)>0:
            matches = list(combo_neg_matches[0])
            side1_drug_match = map(lambda x:reg6.search(x),matches[:2])
            side2_drug_match = map(lambda x:reg6.search(x),matches[2:])
            if (any(elem is not None for elem in side1_drug_match) & (any(elem is not None for elem in side2_drug_match))):
                ind = np.where(np.asarray(side2_drug_match)!=None)[0][0]
                drug_toBe_removed = (matches[2:][ind]).strip(" ")
                print "TEXT", text
                print "REMOVED DRUG", drug_toBe_removed
                drug_found = filter(lambda a: a != drug_toBe_removed, drug_found)  
                print "FINAL DRUG FOUND", drug_found
                #print "####################################################################################################################" 
    return drug_found

        
def drug_tag(text):

    drug_found = []
    orig_text = text
    found_drug = reg6.findall(text)
    for drug in found_drug:
        drug_found.append(drug)

    drug_found = drug_recur(drug_found, orig_text)

    #If a negation term is close to a drug, remove the drug name

    # drug_found = if_drugNegated(drug_found, orig_text)
    #drug_found = combo_neg_handle(drug_found, orig_text)

    return drug_found

    # for drug in drug_found:
    #     text = re.sub(drug + '(?!</DRUG>)', '<DRUG>' + drug + '</DRUG>', text)

    # return text

def neg_tag(text):

    # Initialization
    orig_text = text

    found = NEGATION_RE.findall(text)

    neg_found = if_negCloseToDrug(found,orig_text)

    return neg_found
    
    # for neg in neg_found:
    #     orig_text = re.sub( neg +'(?!</NEG>)', '<NEG>' + neg + '</NEG>', orig_text)

    # return orig_text

def order_words(text):
    orig_text = text

    found = regxp14.findall(text)

    return found
    
    # for order in found:
    #     orig_text = re.sub( order +'(?!</ORDER>)', '<ORDER>' + order + '</ORDER>', orig_text)

    # return orig_text