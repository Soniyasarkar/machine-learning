#Importing packages
import os
import pandas as pd
import numpy as np
import re

#Reading post-level raw data 
data_post  = pd.read_csv("Final_collated_data.csv")
data_v = data_post.dropna(axis=0,how='any')
data_v['Post']= data_v['Post'].map(lambda x:x.decode('utf-8','ignore')) 


#updating drug names
import csv
with open('Melanoma updated drug list_v2.csv') as f:
    d = dict(filter(None, csv.reader(f)))

df1=pd.DataFrame(columns=['Posts_d'])
#df1=posts_arp.dropna(subset=['Post'], how='all')
drug_terms = []
drug_csv = pd.read_csv('Melanoma updated drug list_v2.csv')
drug_terms = drug_csv['drug_nm'].values
#item1 = " arpita sharma lakshya opidivo intron abc Rervoy "
count =0
for item1 in data_v['Post']:
    #print item1
    for item2 in drug_terms:
        try:
            item1= re.sub(r"\b(?=\w)"+re.escape(str(item2))+r"\b(?!\w)", d[item2], item1,flags=re.I) 
        except Exception:
            item1=""
    count += 1
    if (count % 100)==0:
        print count
    df1=df1.append({'Posts_d':item1}, ignore_index=True)

print "Here"

data_v['Posts'] = df1

data_v.to_csv('Data_v.csv',index=False)
