import numpy as np
import pandas as pd
import re
import tempDrugOrderNegTag as tag
from temp2date import temp_to_data
from pattern_ext import patternExtract

Sentence_level = pd.read_csv('Tagged_dataset_sentence_level.csv')     

posts_list = list(Sentence_level['Tokenized.Sentences'])
date_list = list(Sentence_level['date'])

X_1 = []
Y_1 = []
Z_1 = []

for i in range(0,len(Sentence_level['Tokenized.Sentences'])):
    if (i % 100)==0:
        print i
    X,Y,Z= patternExtract(posts_list[i],date_list[i])
    X_1.append(X)
    Y_1.append(Y)
    Z_1.append(Z)
	
Feature_data = pd.DataFrame(
    {'Pattern': X_1,
     'Index': Y_1,
     'Words': Z_1})
	
Feature_data.to_csv('Feature_data_Pattern_v3.csv')