import numpy as np
import pandas as pd
import re
import tempDrugOrderNegTag as tag
from PatternOut import patternExtract
import nltk
from dateutil import parser

sentence_level = pd.read_csv('C:/Users/varun.behl/Documents/data3_filter_tag_drug.csv')

sentence_level['date'] = sentence_level['date'].map(lambda x:parser.parse(x).strftime('%Y-%m-%d'))

posts_list = list(sentence_level['Tokenized.Sentences'])
date_list = list(sentence_level['date'])


X_1 = []
Y_1 = []
Z_1 = []
Temporal = []
Temp_pattern = []
Temp_conversion = []
Temp_index = []
for i in range(0,len(sentence_level['Tokenized.Sentences'])):
    
    print i
    X,Y,Z,A,B,C,D= patternExtract(posts_list[i],date_list[i])
    X_1.append(X)
    Y_1.append(Y)
    Z_1.append(Z)
    Temporal.append(A)
    Temp_pattern.append(B)
    Temp_conversion.append(C)
    Temp_index.append(D)
    
    
Feature_data = pd.DataFrame(
    {'Pattern': X_1,
     'Index': Y_1,
     'Words': Z_1,
     'Temporal': Temporal,
     'Temp_pattern' : Temp_pattern,
     'Temp_conversion' : Temp_conversion,
     'Temp_index' : Temp_index})
     
     
Feature_data.to_csv('Pattern_out_100_user.csv' , index = False)