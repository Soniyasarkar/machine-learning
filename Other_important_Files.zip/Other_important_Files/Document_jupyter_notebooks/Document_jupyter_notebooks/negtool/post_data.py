# -*- coding: utf-8 -*-
"""
Created on Thu Feb 08 07:59:58 2018

@author: Varun.Behl
"""

post_data = pd.read_csv("post_data.csv")