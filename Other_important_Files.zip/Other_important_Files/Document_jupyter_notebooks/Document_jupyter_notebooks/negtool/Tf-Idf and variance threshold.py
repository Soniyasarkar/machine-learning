
# coding: utf-8

# Code for tf-idf and variance threshold

# In[2]:

from sklearn.feature_extraction.text import TfidfTransformer,TfidfVectorizer
from sklearn.feature_selection import VarianceThreshold
import pandas as pd
import numpy as np


# In[ ]:

# Joining the lemmas back to form a string to feed as input to tf-idf vectorizer
#lemmas refer to the tokens generated after lemmatization(its a list of list of tokens)

A=[]
for item in lemmas:
    a= " ".join(str(x) for x in item)
    print a
    A.append(a)


# In[ ]:

sklearn_tfidf = TfidfVectorizer(norm='l2',min_df=0, use_idf=True, smooth_idf=False, sublinear_tf=True, tokenizer=tokenize)
sklearn_representation = sklearn_tfidf.fit_transform(A)
sklearn_representation.toarray()
sklearn_tfidf.get_feature_names()

#saving the model(sklearn.feature_extraction)
# save the model to disk
filename = 'finalized_model.sav'
pickle.dump(model, open(filename, 'wb'))
 
# load the model from disk
loaded_model = pickle.load(open(filename, 'rb'))
result = loaded_model.score(X_test, Y_test)
print(result)


# In[10]:

# selecting 0.1% of the term

from collections import defaultdict
y = len(string_words.split())
z = int(round(y*0.001))
vectorizer = TfidfVectorizer(ngram_range=(1,2))
X = vectorizer.fit_transform(A)
features_by_gram = defaultdict(list)

for f, w in zip(vectorizer.get_feature_names(), vectorizer.idf_):
    features_by_gram[len(f.split(' '))].append((f, w))
    top_n = z for gram, features in features_by_gram.iteritems():
        top_features = sorted(features, key=lambda x: x[1], reverse=False)[:top_n]
        top_features = [f[0] for f in top_features]
        print top_features


# In[39]:

# variance threshold

sel = VarianceThreshold(threshold=(.8 * (1 - .8)))
sel.fit_transform(A)

