import re
import string
import os
import sys
import pandas as pd
import numpy as np

# Requires eGenix.com mx Base Distribution
# http://www.egenix.com/products/python/mxBase/
try:
    from mx.DateTime import *
except ImportError:
    print """
Requires eGenix.com mx Base Distribution
http://www.egenix.com/products/python/mxBase/"""

# Predefined strings.
numbers = "(^a(?=\s)|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred|thousand)"
day = "(monday|tuesday|wednesday|thursday|friday|saturday|sunday|\bmon\b|\btue\b|\bwed\b|\bthurs\b|\bthur\b|\bfri\b|\bsat\b|\bsun\b)"
month = "(january|february|march|april|may|june|july|august|september|october|november|december|\bjan\b|\bfeb\b|\bmar\b|\bapr\b|\bjun\b|\bjul\b|\baug\b|\bsep\b|\boct\b|\bnov\b|\bdec\b)"
dmy = "(year|day|week|month)"
rel_day = "(today|yesterday|tomorrow|tonight|tonite|fortnight)"
exp1 = "(before|after|earlier|later|ago|back)"
exp2 = "(this|next|last|of|till|to|coming)"
exp3 = "(from|since|between|with|past)"
# exp4 = "(treatment|therapy)"
exp5 = "(start)"
iso = "\d+[/-]\d+"
year = "((?<=\s)\d{4}|^\d{4})"
with open("updated_drugs.txt","r") as f:
    drug = f.read()
# drug = "(Pembrolizumab|Nivolumab|Ipilimumab|Interferon|Vemurafenib|Dasatinib|Cisplatin|Vinblastine Sulphate|Temador)"

regxp1 = "((\d+|(" + numbers + "[-\s]?)+) " + dmy + "s? " + "(" + exp1 + "|" + exp3 +"))"
regxp2 = "("+ "("+exp2+"|"+exp3+") "+"((\d+|(" + numbers + "[-\s]?)+) " + dmy + "s?))"
regxp3 = "(" + drug + ")"
regxp4 = "((\d+|(" + numbers + "[-\s]?)+) " + dmy + "s?"+")"
# regxp4 = "5 weeks "
regxp5 =  "("+ "(" + exp2+"|"+ exp3 + ")" + "(" + "( "+dmy+"s?)" + "| " + month+ "| " + day + "| " + rel_day + "| " + year + "| " + iso +")" + " "+ year +")"
regxp6 = "("+ "(" + exp2+"|"+ exp3 + ")" + "(" + "( "+dmy+"s?)" + "| " + month+ "| " + day + "| " + rel_day + "| " + year + "| " + iso +"))"
regxp7 = "("+ "(" "( "+dmy+"s?)" + "| " + month+ "| " + day + "| " + rel_day + "| " + year + "| " + iso +")" +" "+ exp2 +" "+ year+")"
regxp8 = "("+ "(" "( "+dmy+"s?)" + "| " + month+ "| " + day + "| " + rel_day + "| " + year + "| " + iso +")" +" "+ year+")"

# regxp5 = "("+exp5 + "(" + "ed?" +"|"+"ing?" + ")" + "|" + exp3 + ")"
reg1 = re.compile(regxp1, re.IGNORECASE)
reg2 = re.compile(regxp2, re.IGNORECASE)
reg3 = re.compile(rel_day, re.IGNORECASE)
reg4 = re.compile(iso)
reg5 = re.compile(year)
reg6 = re.compile(regxp3,re.IGNORECASE)
reg7 = re.compile(regxp4,re.IGNORECASE)
reg8 = re.compile(regxp5,re.IGNORECASE)
reg9 = re.compile(regxp6,re.IGNORECASE)
reg10 = re.compile(regxp7,re.IGNORECASE)
reg11 = re.compile(regxp8,re.IGNORECASE)
reg12 = re.compile(month,re.IGNORECASE)

NEGATION = "(never|\bno\b|\bover\b|denied|not|wasn't|wasnt|havent|haven't|hasnt|hasn't|hadnt|hadn't|cant|can't|couldnt|couldn't|shouldnt|shouldn't|wont|won't|wouldnt|would not|wouldn't|dont|don't|doesnt|dosen't|didnt|didn't|isnt|isn't|arent|aren't|aint|n't|instead|but|rather)"

NEGATION_RE = re.compile(NEGATION, re.VERBOSE)
allowable_difference = [1,2,3,5]
allowable_words = [' and ']

def recur(timex_found, orig_text):
    dict_timex = {}
    dict_timex['start'] = []
    dict_timex['end'] = []
    for timex in timex_found:
        dict_timex['start'].append(orig_text.find(timex))
        dict_timex['end'].append(orig_text.find(timex)+len(timex))
    start = dict_timex['start']
    end_list = dict_timex['end']
    count = 0
    for end in end_list:
        end_ind = count
        count += 1
        for n in allowable_difference:
            nextStart_ind = np.where(np.asarray(start)==end+n)
            if len(nextStart_ind[0])>0:
                start_ind = nextStart_ind[0][0]
                string_between = orig_text[end:end+n]
                if (string_between in allowable_words) or (n in [1,2,3]):
                    new_timex = timex_found[end_ind]+string_between+timex_found[start_ind]
                    timex_found = list(np.delete(timex_found,[end_ind,start_ind]))
                    timex_found.append(new_timex)
                    timex_found = recur(timex_found,orig_text)
                    return timex_found
    return timex_found

def temporal_tag(text):
    try:
        # Initialization
        timex_found = []
        orig_text = text

        ##WITH PRIORITY

        # Variations of this thursday, next year, etc
        found = reg2.findall(text)
        found = [a[0] for a in found if len(a) > 1]
        for timex in found:
            timex_found.append(timex)
            text = re.sub(timex,'',text)

        found = reg1.findall(text)
        found = [a[0] for a in found if len(a) > 1]
        for timex in found:
            timex_found.append(timex)
            text = re.sub(timex,'',text)

        found = reg7.findall(text)
        found = [a[0] for a in found if len(a) > 1]
        for timex in found:
            timex_found.append(timex)
            text = re.sub(timex,'',text)

        found = reg10.findall(text) 
        found = [a[0] for a in found if len(a) > 1] 
        for timex in found:
            timex_found.append(timex)
            text = re.sub(timex,'',text)

        found = reg11.findall(text) 
        found = [a[0] for a in found if len(a) > 1] 
        for timex in found:
            timex_found.append(timex)
            text = re.sub(timex,'',text)

        found = reg8.findall(text)
        found = [a[0] for a in found if len(a) > 1]
        for timex in found:
            timex_found.append(timex)
            text = re.sub(timex,'',text)

        found = reg9.findall(text)
        found = [a[0] for a in found if len(a) > 1]
        for timex in found:
            timex_found.append(timex)
            text = re.sub(timex,'',text)
                
        found = reg5.findall(text)
        for timex in found:
            timex_found.append(timex)
            text = re.sub(timex,'',text)

        # today, tomorrow, etc
        found = reg3.findall(text)
        for timex in found:
            timex_found.append(timex)
            text = re.sub(timex,'',text)

        # ISO
        found = reg4.findall(text)  
        for timex in found:
            timex_found.append(timex)
            text = re.sub(timex,'',text)

        found = reg12.findall(text)
        for timex in found:
            timex_found.append(timex)
            text = re.sub(timex,'',text)

        timex_found = recur(timex_found, orig_text)

            # Tag only temporal expressions which haven't been tagged.
        for timex in timex_found:
            orig_text = re.sub(timex + '(?!</TIMEX2>)', '<TIMEX2>' + timex + '</TIMEX2>', orig_text)

        return orig_text

    except:
        print text
        
def drug_tag(text):

    drug_found = []
    found_drug = reg6.findall(text)
    found_drug = [a[0] for a in found_drug if len(a) > 1]
    for drug in found_drug:
        drug_found.append(drug)

    for drug in drug_found:
        text = re.sub(drug + '(?!</DRUG>)', '<DRUG>' + drug + '</DRUG>', text)
    return text

def neg_tag(text):

    # Initialization
    neg_found = []
    orig_text = text

    ##WITH PRIORITY

    # Variations of this thursday, next year, etc
    found = NEGATION_RE.findall(text)
    print found
    # found = [a[0] for a in found if len(a) > 1]
    for neg in found:
        neg_found.append(neg)
        text = re.sub(neg,'',text)
    
    
    for neg in neg_found:
        orig_text = re.sub( neg +'(?!</NEG>)', '<NEG>' + neg + '</NEG>', orig_text)

    return orig_text


x_1 = pd.read_csv('Seletec_users_100.csv',low_memory=False)

A_list_ = pd.DataFrame(x_1['Tokenized.Sentences'].map(lambda x:temporal_tag(x)))

# A_list_.to_csv("A_list.csv")

Temporal_words = pd.DataFrame(A_list_['Tokenized.Sentences'].map(lambda x:np.unique(re.findall('<TIMEX2>(.*?)</TIMEX2>',str(x)))))

B_list_ = pd.DataFrame(x_1['Tokenized.Sentences'].map(lambda x:drug_tag(x)))

Drug_mentions = pd.DataFrame(B_list_['Tokenized.Sentences'].map(lambda x:np.unique(re.findall('<DRUG>(.*?)</DRUG>',x))))

C_list_ = pd.DataFrame(x_1['Tokenized.Sentences'].map(lambda x:neg_tag(x)))

Negations = pd.DataFrame(C_list_['Tokenized.Sentences'].map(lambda x:np.unique(re.findall('<NEG>(.*?)</NEG>',x))))

x_1['temp']= Temporal_words
x_1['Drug']=Drug_mentions
x_1['Negations']=Negations

x_1.to_csv('Seletec_users_100_tagged.csv')

# tag = temporal_tag(str('I was initially diagnosed stage 3C in 11/2007.' 'I had a tumor in the lymph nodes in the right axillary (armpit).''I had an unknown primary and some ulceration.''I had surgery to remove the tumor.' 'Next I had 6 weeks ago of radiation on the tumor site.' 'According to my onc. this decreased the chances of a local recurrence from 60 to 10%.' 'Then I was given the option of Interferon do nothing or a clinical trial with MDX-010 (Ipilimumab Ipilimumab and peptide vaccines.' 'I decided on the clinical trial.' "I was on Ipilimumab from 3/08 to 10/08 with a dose of 10mg/kg( I'm sure since it has been approved the dose given is less like 3mg/kg)." "Ipilimumab swelled my pituitary gland so I was taken off Ipilimumab and given a steroid as a hormone replacement ( I've been on the steroid 2.5 years and haven't been able to taper off it)." 'I am a responder to Ipilimumab as it boosted my immune system at least 5 times over baseline.' 'I also developed lymphedema in my right arm which is manageable.' "I'm feeling good working full time and just go for follow-up scans." '\xc3\x82\xc2 This is just my experience.' 'As others have said there are different options.' "I'd recommend finding a melanoma specialist." 'My surgical onc.' '\xc3\x82\xc2 does\xc3\x82\xc2 LNDs on a regular basis which gave me comfort.' 'I go to Moffitt Cancer\xc3\x82\xc2 Center in Tampa Fl. a comprehensive cancer center.' 'It is next to a university and thus is a research center.' 'Much success and God Bless   \xc3\x82\xc2 Jim M.' '\xc3\x82\xc2 Stage 3C   NED 3.5 years'))
# tag = temporal_tag("ipi for Nov, 2012 and I was initially diagnosed stage 3C in 11/2007 also for 5 weeks 9 months and 5 days.")
# print tag