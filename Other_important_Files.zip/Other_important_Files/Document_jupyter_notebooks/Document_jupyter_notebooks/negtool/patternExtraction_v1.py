import numpy as np
import pandas as pd
import re
import nltk
import collections
import os
import tempDrugOrderNegTag as tag
from sutime import SUTime

global pattern_dict
global word_dict

jar_files = 'C:/Users/varun.behl/Documents/python-sutime-master/sutime/jars/'
sutime = SUTime(jars=jar_files,jvm_started= True , mark_time_ranges= True , include_range= True )

# text = "I am taking Ipilimumab for last 10 months. Before that I was on Nivolumab from January 2015. But instead of Ipilimumab I should have taken Vemurafenib for 10 days"
# postDate = "3/7/2018  12:00:00 AM"

def get_index(typeString,replaceString,words_list,text):
    global pattern_dict
    global word_dict
    words_unique = np.unique(words_list).tolist()
    words_sorted = sorted(words_unique, key=len, reverse=True)
    for word in words_sorted:
        text = re.sub(word.strip(" "),word.replace(" ","")+(" "),text)
        text_list = text.split(" ")
        ind = np.where(np.asarray(text_list)==word.replace(" ",""))[0]
        for i in ind:
            pattern_dict[i] = typeString
            word_dict[i] = word
        text = re.sub(word.replace(" ",""),replaceString,text)
    return text

def patternExtract(text, postDate):
    global pattern_dict
    global word_dict
    pattern_dict = {}
    word_dict = {}
    

    x = sutime.parse(text , reference_date= postDate)
    
    Temporal = []
    Temp_pattern = []
    Temp_conversion  = []
    
    
    for i in range(len(x)):
        Temporal.append(x[i]['text'])
        Temp_pattern.append('T'+re.escape(str(i)))
        Temp_conversion.append(x[i]['value'])
    
    
    drug_words = tag.drug_tag(text)
    order_words = tag.order_words(text)
    neg_words = tag.neg_tag(text)
   


    drug_count = 0
    temp_count = 0
    order_count = 0

    text = get_index('D','DRUG',drug_words,text)
    text = get_index('O','ORDER',order_words,text)
    text = get_index('N','NEG',neg_words,text)
    
    Temp_index = []
    for y in Temporal:
        z = y.split(" ")[0]
        Temp_index.append(nltk.word_tokenize(text).index(z))

    od_pattern = collections.OrderedDict(sorted(pattern_dict.items()))
    od_words = collections.OrderedDict(sorted(word_dict.items()))

    indices = list(od_pattern.keys())
    pattern = list(od_pattern.values())
    words = list(od_words.values())

    return pattern, indices, words , Temporal , Temp_pattern , Temp_conversion , Temp_index

# pattern, ind, words = patternExtract(text, postDate)
# print pattern
# print ind
# print words