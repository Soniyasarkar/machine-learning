import re
import string
import os
import sys
import pandas as pd
import numpy as np

# NEGATION = r"""
#     (?:
#         ^(?:never|no|nothing|nowhere|noone|none|not|
#             havent|hasnt|hadnt|cant|couldnt|shouldnt|
#             wont|wouldnt|dont|doesnt|didnt|isnt|arent|aint
#         )$
#     )
#     |
#     n't"""

NEGATION = "(never|no|nothing|nowhere|none|not|havent|hasnt|hadnt|cant|couldnt|shouldnt|wont|wouldnt|dont|doesnt|didnt|isnt|arent|aint|n't|instead|but|rather)"
NEGATION_RE = re.compile(NEGATION, re.VERBOSE)

def neg_tag(text):

    # Initialization
    neg_found = []
    orig_text = text

    ##WITH PRIORITY

    # Variations of this thursday, next year, etc
    found = NEGATION_RE.findall(text)
    print found
    # found = [a[0] for a in found if len(a) > 1]
    for neg in found:
        neg_found.append(neg)
        text = re.sub(neg,'',text)
    
    
    for neg in neg_found:
        orig_text = re.sub( neg +'(?!</NEG>)', '<NEG>' + neg + '</NEG>', orig_text)

    return orig_text
	
text = "My doctor prescribed me to take Ipi but I am taking Vemura"
# text = "I dont like butter"
text_neg = neg_tag(text)

print text_neg