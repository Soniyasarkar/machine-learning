# -*- coding: utf-8 -*-
"""
Created on Fri Aug 25 22:28:17 2017

@author: Varun.Behl
"""

a=int(input("Enter the first number:"))
b=int(input("Enter the second number:"))
if(a>b):
    min1=a
else:
    min1=b
while(1):
    if(min1%a==0 and min1%b==0):
        print("LCM is:",min1)
        break
    min1=min1+1