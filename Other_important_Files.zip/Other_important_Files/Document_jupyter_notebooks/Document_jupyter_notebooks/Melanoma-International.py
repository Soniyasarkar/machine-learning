
# coding: utf-8

# In[2]:

from bs4 import BeautifulSoup


# In[3]:

import requests
import json
import urllib2
import pandas as pd


# In[14]:

df = pd.DataFrame(columns=['Link'])
for i in xrange(90,105):
    #link = ("http://forum.melanomainternational.org/mif/melanoma-newly-diagnosed-stages-i-&-ii-f56s"+str(i*25)+".html")
    #link =("http://forum.melanomainternational.org/mif/melanoma-diagnosis-stages-i-&ii-f53s"+str(20*25)+".html")
    #link = ("http://forum.melanomainternational.org/mif/newly-diagnosed-stage-iii-iv-f64s"+str(i*25)+".html")
    #link =("http://forum.melanomainternational.org/mif/melanoma-stage-iii-f62s"+str(10*25)+".html")
    link = ("http://forum.melanomainternational.org/mif/melanoma-diagnosis-stage-iv-f54s"+str(i*25)+".html")
    mel_inter = requests.get(link)
    soup = BeautifulSoup(mel_inter.content, 'html.parser')
    for item1 in soup.find_all(class_="row bg1"):
        good1=item1.find(class_="topictitle")['href']
        df= df.append({'Link': good1}, ignore_index=True) 
    for item2 in soup.find_all(class_="row bg2"):
        good2=item2.find(class_="topictitle")['href']
        df= df.append({'Link': good2}, ignore_index=True) 
    print df
            
           
   


# In[15]:

finaldf = pd.DataFrame(columns=['Link'])
i=0
for item in df.Link:
    newitem = item[1:]
    newitem1 = newitem.encode('utf-8')
    finallink = ("http://forum.melanomainternational.org/mif"+str(newitem1))
    finaldf=finaldf.append({'Link': finallink}, ignore_index=True)
print finaldf.Link


# In[16]:

df1 = pd.DataFrame(columns = ['Title','User','Date','Post'])
for item in finaldf.Link:
    post1 = requests.get(item)
    soup = BeautifulSoup(post1.content, 'html.parser')
    for item in soup.find_all(class_="post bg2"):
        posts=item.find(class_="postbody")
        Title=posts.find("a")
        title_temp=Title.text.strip().encode('utf-8')
        User=posts.find("strong")
        user_temp= User.text.strip().encode('utf-8')
        date=posts.find(class_="author")
        date1=date.text.strip()
        date_temp=date1.split(' ', 3)[3]
        apost= posts.find(class_="content")
        post_temp=apost.text.strip().encode('utf-8')
        df1 = df1.append({'Title': title_temp , 'User' : user_temp,'Date' : date_temp, 'Post' : post_temp}, ignore_index=True)
    for item in soup.find_all(class_="post bg1"):
        posts=item.find(class_="postbody")
        Title=posts.find("a")
        title_temp=Title.text.strip().encode('utf-8')
        User=posts.find("strong")
        user_temp= User.text.strip().encode('utf-8')
        date=posts.find(class_="author")
        date1=date.text.strip()
        date_temp=date1.split(' ', 3)[3]
        apost= posts.find(class_="content")
        post_temp=apost.text.strip().encode('utf-8')
        df1 = df1.append({'Title': title_temp , 'User' : user_temp,'Date' : date_temp, 'Post' : post_temp}, ignore_index=True)
    print df1
    
df1.to_csv("C:\\Users\\Arpita.Sharma\\Documents\\testdir\\mel_inter34.csv", sep=',', encoding='utf-8')

