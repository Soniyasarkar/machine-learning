import pandas as pd
import re
import csv

posts_arp= pd.read_csv('post_level_data_sma.csv')

with open('Melanoma updated drug list_v2.csv') as f:
    d = dict(filter(None, csv.reader(f)))
	

df1=pd.DataFrame(columns=['Posts_d'])
#df1=posts_arp.dropna(subset=['Post'], how='all')
drug_terms = []
drug_csv = pd.read_csv('Melanoma updated drug list_v2.csv')
drug_terms = drug_csv['drug_nm'].values
#item1 = " arpita sharma lakshya opidivo intron abc Rervoy "
count = 0 
for item1 in posts_arp['Posts']:
    #print item1
    for item2 in drug_terms:
        try:
            item1= re.sub("\\b"+str(item2), d[item2], item1,flags=re.I)
            count += 1
        except Exception:
            item1=""
    df1=df1.append({'Posts_d':item1}, ignore_index=True)
	


posts_arp['posts_p']= df1

posts_arp.to_csv('post_level_arp.csv')