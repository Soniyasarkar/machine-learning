
# coding: utf-8

# In[1]:

from bs4 import BeautifulSoup


# In[2]:

import requests
import json
import urllib2
import pandas as pd


# In[3]:

df = pd.DataFrame(columns=['Link'])
#df = pd.DataFrame(columns=['Title','Link'])
cancerwebsite="https://csn.cancer.org/forum/145"
for i in xrange(5,7):
    link = ("https://csn.cancer.org/forum/145?page="+str(i))
    csn_cancer = requests.get(link)
    soup = BeautifulSoup(csn_cancer.content, 'html.parser')
    for item1 in soup.find_all(class_="odd"):
            good=item1.find(class_="title")
            good1=good.find("a")['href']
            good2="https://csn.cancer.org"+str(good1)
            df= df.append({'Link': good2}, ignore_index=True)
            print df
    for item2 in soup.find_all(class_="even"):
            goode=item2.find(class_="title")
            good1e=goode.find("a")['href']
            good2e="https://csn.cancer.org"+str(good1e)
            df= df.append({'Link': good2e}, ignore_index=True)
            print df


# In[4]:

df1 = pd.DataFrame(columns = ['Title','User','Date','Post'])
for item in df.Link:
    post1 = requests.get(item)
    soup = BeautifulSoup(post1.content, 'html.parser')
    for item in soup.find_all(class_="with-tabs"):
        title_temp=item.text.strip().encode('utf-8')
    #for main posts
    for item in soup.find_all(class_="node node-forum"):
        good1=item.find(class_="node-left")
        user=good1.find(class_="username")
        user_temp=user.text.strip().encode('utf-8')
        good2=item.find(class_="node-right")
        date=good2.find(class_="submitted")
        date_temp= date.text.strip().encode('utf-8')
        posts=good2.find(class_="content")
        post_temp= posts.text.strip().encode('utf-8')
        df1 = df1.append({'Title': title_temp , 'User' : user_temp,'Date' : date_temp, 'Post' : post_temp}, ignore_index=True)
    #for comments
    for itemc in soup.find_all(class_="comment comment-forum odd"):
        goodc=itemc.find(class_="comment-left")
        userc=goodc.find(class_="username")
        user1c_temp= userc.text.strip().encode('utf-8')
        good1c=itemc.find(class_="comment-right")
        datec=good1c.find(class_="submitted")
        date1c_temp= datec.text.strip().encode('utf-8')
        postsc=good1c.find(class_="content")
        posts1c_temp= postsc.text.strip().encode('utf-8')
        df1 = df1.append({'Title': title_temp , 'User' : user1c_temp,'Date' : date1c_temp, 'Post' : posts1c_temp}, ignore_index=True)
    print df1
    
df1.to_csv("C:\\Users\\Arpita.Sharma\\Documents\\testdir\\csn3.csv", sep=',', encoding='utf-8')

