
# coding: utf-8

# Filtering Post for drug mentions

# In[1]:

# Importing packages

import pandas as pd
import re
import csv
import random


# In[17]:

# Reading data from csv file and storing in a dataframe

posts_arp= pd.read_csv('C:\\Users\\Arpita.Sharma\\Desktop\\Collated_data.csv')
posts_arp


# In[18]:

# Replacing all the misspelled, abbreviated and incorrect drug names with the correct drug names.

# importing the correct-incorrect drug name as dictionary
with open('C:\\Users\\Arpita.Sharma\\Desktop\\sml final\\Melanoma drug list-dict.csv') as f:
    d = dict(filter(None, csv.reader(f)))
df1=pd.DataFrame(columns=['Posts_d'])
drug_terms = []
drug_csv = pd.read_csv('C:\\Users\\Arpita.Sharma\\Desktop\\sml final\\Melanoma drug list.csv')
drug_terms = drug_csv.drug_nm

#replacing the incorrect word with right word
for item1 in posts_arp.Post:
    for item2 in drug_terms:
        try:
            item1= re.sub("\\b"+str(item2)+"[\W_]+", d[item2]+" ", item1,flags=re.I)
        except Exception:
            item1=""
    print item1       
    df1=df1.append({'Posts_d':item1}, ignore_index=True)
    df1


# In[13]:




# In[14]:

# creating a new column for the corrected posts
posts_arp['posts_p']=df1


# In[15]:

#Dropping the actual column
posts_arp=posts_arp.drop(['Post'],axis=1)

# Storing in a csv
posts_arp.to_csv("filtered_cancer_compass.csv")



# In[16]:



# filtering posts for drug mentions
drug_terms = []
drug_csv = pd.read_csv('C:\\Users\\Arpita.Sharma\\Desktop\\sml final\\Melanoma drug list.csv')
drug_terms = drug_csv.drug_nm

#print drug_terms
pattern = '|'.join(drug_terms)

#dropping na values from df
df1=posts_arp.dropna(subset=['posts_p'], how='all')
for_new_df = df1[df1['posts_p'].str.contains(pattern)]
for_new_df
for_new_df.to_csv("C:\\Users\\Arpita.Sharma\\Desktop\\filtered_posts2\\collated_data.csv", sep=',', encoding='utf-8')


# In[12]:

# generating unique ids for each post

df1=pd.DataFrame(columns=['ids'])
for i in range(100):
    A='{0:05}'.format(random.randint(1, 100000))
    print A
    df1=df1.append({'ids':A}, ignore_index=True)
df1.to_csv("unique_ids.csv")


# In[ ]:

# Shuffling the data and writing to csv

posts_arp = posts_arp.sample(frac=1).reset_index(drop=True)
posts_arp.to_csv("Filtered_shuffled.csv")

