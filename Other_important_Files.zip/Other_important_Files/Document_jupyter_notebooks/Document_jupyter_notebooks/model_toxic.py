# Importing necassary packages 
import string
import pandas as pd
import numpy as np
import nltk
import re

# Sklearn package to import necessary vectorizing algorithms
from sklearn.feature_extraction.text import TfidfTransformer,TfidfVectorizer

#NLTK package for text mining operations 
from nltk.corpus import stopwords as sw
from nltk.corpus import wordnet as wn
from nltk import wordpunct_tokenize
from nltk import WordNetLemmatizer
from nltk import sent_tokenize
from nltk.tokenize import sent_tokenize
from nltk import pos_tag

from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report as clsr
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
from sklearn.naive_bayes import MultinomialNB
from sklearn.neighbors import KNeighborsClassifier
import pickle
from sklearn.cross_validation import KFold
from nltk.tokenize import sent_tokenize
#from __future__ import division
from scipy import sparse , vstack , hstack
from sklearn.svm import SVC
from sklearn.utils import check_random_state, safe_indexing

# Reading the sentenced tokenized dataset
posts = pd.read_csv('Toxic_comment_filter_data.csv')

# Dependent variable is defined
y = posts["toxic"]
subsample_size = 1.0


List_strings= list(posts['Comment'])

vectorizer = TfidfVectorizer(use_idf= True)
#vectorizer= CountVectorizer()
X_1 = vectorizer.fit_transform(List_strings)
#Vectorized output is in csr matrix format

from sklearn.cross_validation import train_test_split as tts
from scipy import sparse

#Training and testing split - with a split of 70:30
X_train, X_test, y_train, y_test = tts(X_1,y, test_size=0.2, random_state=123)

# from sklearn.svm import SVC

classifier = SVC(kernel= 'linear' , C =1 )
model = classifier.fit(X_train ,y_train) 
#tfs_test = vectorizer.transform(X_test)
feature_test = X_test
y_pred = classifier.predict(feature_test)

print(clsr(y_test.tolist(), y_pred.tolist()))