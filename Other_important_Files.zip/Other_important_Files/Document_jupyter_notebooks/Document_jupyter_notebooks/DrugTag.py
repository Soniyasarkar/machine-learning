import re
import numpy as np
import pandas as pd
 
orderwords = "(later|before|earlier|previous|then|subsequently|followed|post|prior|after)"
 
with open("/mnt/Data/Input/updated_drugs.txt","r") as f:
    drug = f.read()
 
drugtag_regxp = "("r"\b(?!\w)"+drug+r"\b(?!\w))"
drugtag_reg = re.compile(drugtag_regxp,re.IGNORECASE)
 
 
combo_neg = "rather|but|over|instead"
 
NEGATION = "(never|\bno\b|\bover\b|denied|not|wasn't|wasnt|havent|haven't|hasnt|hasn't|hadnt|hadn't|cant|can't|couldnt|couldn't|shouldnt|shouldn't|wont|won't|wouldnt|would not|wouldn't|dont|don't|doesnt|dosen't|didnt|didn't|isnt|isn't|arent|aren't|aint|n't|instead|but|rather)"
NEGATION_RE = re.compile(NEGATION, re.VERBOSE)
 
#If two drugs are seperated by allowable_difference_drug and has allowable_words_drug separating them, we consider take them as combo drugs 
allowable_difference_drug = [1,2,3,4,5,6,7,12]
allowable_words_drug = "(and|&|with|/|-|,|)"
drugexp = re.compile(allowable_words_drug,re.IGNORECASE)
 
orderexp = re.compile(orderwords, re.IGNORECASE)
 
neg_toBeRemoved = []
 
# Recursively checks if 2 drugs in a sentence are combo drug or not
def drug_recur(drug_found, orig_text):
    #dict_drug has the start ind and end ind of all the drugs in drug_found
    dict_drug = {}
    dict_drug['start'] = []
    dict_drug['end'] = []
    text_copy = orig_text
    for drug in drug_found:
        dict_drug['start'].append(text_copy.find(drug))
        dict_drug['end'].append(text_copy.find(drug)+len(drug))
        text_copy = re.sub(drug,drug.upper(),text_copy, 1)
    start = dict_drug['start']
    end_list = dict_drug['end']
    count = 0
 
    for end in end_list:
        end_ind = count
        count += 1
        # Only check for allowable index difference 
        for n in allowable_difference_drug:
            nextStart_ind = np.where(np.asarray(start)==end+n)
            if len(nextStart_ind[0])>0:
                start_ind = nextStart_ind[0][0]
                string_between = orig_text[end:end+n]
                matches_forDrug = drugexp.findall(string_between)
                matches_forDrug = filter(lambda a: a != '', matches_forDrug)
                if ((len(matches_forDrug)>0) or (n==1)):
                    # If the string between 2 drugs is in allowable_words_drug list, the 2 drugs are taken as a combo
                    new_drug = drug_found[end_ind]+string_between+drug_found[start_ind]
                    drug_found = list(np.delete(drug_found,[end_ind,start_ind]))
                    drug_found.insert(end_ind,new_drug)
                    # If both the drugs are next to each other, then assume them as a combo
                    if n==1:
                        print "n==1",drug_found
                    # Recursive call
                    drug_found = drug_recur(drug_found,orig_text)
                    return drug_found
    return drug_found
        
def drug_tag(text):
 
    drug_found = []
    orig_text = text
    found_drug = drugtag_reg.findall(text)
    for drug in found_drug:
        drug_found.append(drug)
    
    drug_found = drug_recur(drug_found, orig_text)
 
    return drug_found
 
def neg_tag(text):
 
    # Initialization
    orig_text = text
 
    found = NEGATION_RE.findall(text)
    neg_found = found
    return neg_found
 
 
def order_words(text):
    orig_text = text
 
    found = orderexp.findall(text)
 
    return found