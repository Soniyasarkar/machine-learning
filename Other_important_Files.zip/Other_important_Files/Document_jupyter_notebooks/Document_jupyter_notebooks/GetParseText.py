import re
import networkx as nx
import xmltodict
import ast
import pandas as pd
import numpy as np

def isDrugMention(token):
    with open("updated_drugs_v2.txt","r") as f:
        drug = f.read()
    try:
        
        if len(re.findall(r"\b(?=\w)"+token+r"\b(?!\w)",drug))>=1:
            #print 1
            return 1
    except:
        return 0

def consecutive(data, stepsize=1):
    return np.split(data, np.where(np.diff(data) != stepsize)[0]+1)

def getmin(l,wordsInTemp):
    if(len(l)==wordsInTemp):
        return l[0]
    else:
        return None



def xml_input(unique_id):
    xmlfile = 'post'+'_'+unique_id+'.txt.xml'

    with open('C:/Users/varun.behl/Documents/test_plain_text_updated/output_from_domino/'+xmlfile) as fd:
        doc2 = xmltodict.parse(fd.read())

    _id = []
    wi =[]
    word = []
    lemma = []
    cpostag = []
    head = []
    deprel = []
    token_dict = {}
    word_index = {}
    conll_pattern = []
    conll_index = []

    sentence_start = []
    sentence_start.append(1)
    for i in range(1,len(doc2['CAS']['org.apache.ctakes.typesystem.type.syntax.ConllDependencyNode'])):
        if doc2['CAS']['org.apache.ctakes.typesystem.type.syntax.ConllDependencyNode'][i]['@id'].encode("utf-8")=='0':
            sentence_start.append(prev_token+1)
            continue
        token_dict[(doc2['CAS']['org.apache.ctakes.typesystem.type.syntax.ConllDependencyNode'][i]['@_id']).encode("utf-8")]=[i,(doc2['CAS']['org.apache.ctakes.typesystem.type.syntax.ConllDependencyNode'][i]['@cpostag']).encode("utf-8")]
        _id.append((doc2['CAS']['org.apache.ctakes.typesystem.type.syntax.ConllDependencyNode'][i]['@_id']).encode("utf-8"))
        wi.append((doc2['CAS']['org.apache.ctakes.typesystem.type.syntax.ConllDependencyNode'][i]['@id']).encode("utf-8"))
        wix = doc2['CAS']['org.apache.ctakes.typesystem.type.syntax.ConllDependencyNode'][i]['@id'].encode("utf-8")
        head.append((doc2['CAS']['org.apache.ctakes.typesystem.type.syntax.ConllDependencyNode'][i]['@_ref_head']).encode("utf-8"))
        cpostag.append((doc2['CAS']['org.apache.ctakes.typesystem.type.syntax.ConllDependencyNode'][i]['@cpostag']).encode("utf-8"))
        word = doc2['CAS']['org.apache.ctakes.typesystem.type.syntax.ConllDependencyNode'][i]['@form'].encode("utf-8")
        if isDrugMention((doc2['CAS']['org.apache.ctakes.typesystem.type.syntax.ConllDependencyNode'][i]['@form']).encode("utf-8")):
            conll_pattern.append('D')
            conll_index.append(int((doc2['CAS']['org.apache.ctakes.typesystem.type.syntax.ConllDependencyNode'][i]['@id']).encode("utf-8"))-1)
        prev_token=int(doc2['CAS']['org.apache.ctakes.typesystem.type.syntax.ConllDependencyNode'][i]['@id'])
        word_index[wix] =word
        
        #print prev_token
    #print "lenght:", len(doc2['CAS']['org.apache.ctakes.typesystem.type.syntax.ConllDependencyNode'])
    head_index = []
    head_pos = []
    for i in range(0,len(head)):
        try:
            head_index.append(token_dict[str(head[i])][0])
            head_pos.append(token_dict[str(head[i])][1])
        except:
            head_index.append(0)
            head_pos.append(cpostag[i])
            
    #print wi        
    sent_list = []
    dep_list = []
    sentence_count = 0
    for i in range(0,len(head)):
        if wi[i] == sentence_start[sentence_count]:
            sent_list.append(dep_list)
            sentence_count += 1
            dep_list = []
        w_i = wi[i]
        h_i = str(head_index[i])
        dep_tup = (h_i,w_i)
        dep_list.append(dep_tup)
    sent_list.append(dep_list)


    return sent_list , word_index
    
def association(i,u_pattern,u_index ,u_words,temp_words , temp_conversion , Unique_id ,temp_index ):
    
    global word_index
    sent = xml_input(Unique_id)
    graph = nx.Graph(sent[0])
    #print sent[0]
    associated_list = []
    converted_temp = []
    for index_d,value_d in enumerate(u_pattern):
        #print index
        #print value

        if(u_pattern[index_d]=='D'):
            Drug=u_words[index_d]
            allowable_words_drug= "(and|&|with|/|-|,)"
            drugexp = re.compile(allowable_words_drug,re.IGNORECASE)
            drug_list = re.sub(allowable_words_drug,' ',Drug)
            druglist = drug_list.split(" ")
            wordsInDrug = len(drug_list)
            drug_indices = np.array([int(key) for key, value in word_index.iteritems() if value == druglist])
            consecutive_drug = consecutive(sorted(drug_indices))
            val_drug = np.asarray(map(lambda y: getmin(y,wordsInDrug),consecutive_drug))
            distance_drug = val_drug[np.where(val_drug!=None)]
            try:
                assert(len(distance_drug)==1)
            except AssertionError:
                print "Too many lists match the condition_drug"
                
            #temp_indices = np.array([int(key) for key, value in words_index.iteritems() if value in temp_list])
            #print Drug
            past=1000
            actual_temporal=''
            for index_t,value_t in enumerate(temp_words):
                temporal_word=temp_words[index_t]
                temp_list = nltk.word_tokenize(temporal_word)
                wordsInTemp = len(temp_list)
                temp_indices = np.array([int(key) for key, value in word_index.iteritems() if value in temp_list])
                consecutive_temp = consecutive(sorted(temp_indices))
                val_temp = np.asarray(map(lambda x: getmin(x,wordsInTemp),consecutive_temp))
                distance_temp = val_temp[np.where(val_temp!=None)]
                
                try:
                    assert(len(distance_temp)==1)
                except AssertionError:
                    print "Too many lists match the condition_temp"
                
                #print temporal_word
                try:
                    distance_value=nx.shortest_path_length(graph, source=str(distance_drug), target=str(distance_temp))
                except :
                    distance_value = 4

                    #print distance_value
                if distance_value<past and distance_value<=4:
                    past=distance_value
                    actual_temporal=temporal_word
                    associated_list.append((Drug,actual_temporal))
                    converted_temp.append(temp_conversion[index_t])
    return associated_list , converted_temp