
# coding: utf-8

# In[ ]:

import requests
from bs4 import BeautifulSoup
import pandas as pd
p=0
df = pd.DataFrame(columns=['Title','User','Date','Post'])
melanowebsite="https://www.melanomanetwork.ca"
for i in xrange(1,12):
    link = ("https://www.melanomanetwork.ca/forums/page/"+str(i)+"/")
    melano = requests.get(link)
    soup = BeautifulSoup(melano.content, 'html.parser')
    for disc in soup.find_all(class_="bbp-topic-permalink"):
        title=disc.text.strip()
        link2 = disc['href']
        melano2 = requests.get(link2)
        soup2 = BeautifulSoup(melano2.content, 'html.parser')
        for temp in soup2.find_all("li"):
            for disc3,disc1,disc2 in zip(temp.find_all(class_="bbp-reply-post-date"),temp.find_all(class_="bbp-author-name"),temp.find_all(class_="bbp-reply-content")):
                Title_temp=title.encode('utf-8')
                print Title_temp,p
                p=p+1
                date_temp=disc3.text.strip().encode('utf-8')
                author_temp=disc1.text.strip().encode('utf-8')
                content_temp=''
                for p_tag in disc2.find_all('p'):
                    content_temp=content_temp+" "+p_tag.text.strip()
                content_temp.encode('utf-8')
                df = df.append({'Title': Title_temp,'User': author_temp,'Date':date_temp,'Post':content_temp}, ignore_index=True)


