import negtool
import utils as negutil
import pickle
from sklearn.externals import joblib


def load_cue_learner():
    """
    Loads the object containing the cue learner from file
    Returns the cue learner, the cue vectorizer, the cue lexicon and the
    affixal cue lexicon
    """
    cue_ssvm = pickle.load(open("C:/Users/varun.behl/Documents/negtool_files/negtool/objectfiles/cue_model.pkl", "rb"))
    cue_vectorizer = joblib.load("C:/Users/varun.behl/Documents/negtool_files/negtool/objectfiles/cue_vectorizer.pkl")
    cue_lexicon = pickle.load(open("C:/Users/varun.behl/Documents/negtool_files/negtool/objectfiles/cue_lexicon.pkl", "rb"))
    affixal_cue_lexicon = pickle.load(open("C:/Users/varun.behl/Documents/negtool_files/negtool/objectfiles/affixal_cue_lexicon.pkl", "rb"))
    return cue_ssvm, cue_vectorizer, cue_lexicon, affixal_cue_lexicon

def load_scope_learner():
    """
    Loads the object containing the scope learner from file
    Returns the scope learner and the scope vectorizer
    """
    scope_ssvm = pickle.load(open("C:/Users/varun.behl/Documents/negtool_files/negtool/objectfiles/scope_model.pkl", "rb"))
    scope_vectorizer = joblib.load("C:/Users/varun.behl/Documents/negtool_files/negtool/objectfiles/scope_vectorizer.pkl")
    return scope_ssvm, scope_vectorizer
